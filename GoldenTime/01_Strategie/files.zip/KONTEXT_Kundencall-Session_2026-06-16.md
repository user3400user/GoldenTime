# Kontext: Kundencall-Session — GoldenTime / Gewerbespeicher-Leads
**Erstellt 16.06.2026 · Zweck: Diese Datei gibt einer SEPARATEN Claude-Session den vollen Kontext für die Vorbereitung und Auswertung echter Kundengespräche. Sie ist eigenständig — die Session muss nichts anderes kennen.**

> Diese Session macht NICHT den Build und NICHT die Konzeptarbeit. Sie macht EINE Sache: herausfinden, wie der Kunde am liebsten einen Lead bekommt und wo er den größten Wert sieht. Alles hier dient diesem Ziel.

---

## 1 · Was GoldenTime ist (in 60 Sekunden)
Wir verkaufen Verkaufssignale an regionale Gewerbespeicher-Anbieter. Quelle: das öffentliche Marktstammdatenregister (MaStR) der Bundesnetzagentur. Wir erkennen Betriebe, bei denen gerade ein Kaufanlass für einen Batteriespeicher entstanden ist, und liefern das als strukturiertes Signal — wöchentlich, regional, exklusiv pro Käufer.

**Warum das einen Wert hat:** Ein einzelner Gewerbespeicher-Auftrag ist für den Installateur 30.000–150.000 € wert. Wer im richtigen Moment den richtigen Betrieb anspricht, gewinnt Aufträge, die sonst der Wettbewerb oder niemand macht. Wir liefern den Moment.

**Die Trigger (Kaufanlässe), die wir erkennen:**
- **T1 Neuanmeldung:** Betrieb hat gerade gewerbliche PV ohne Speicher angemeldet → Eigenverbrauch läuft, Speicher fehlt noch.
- **T2 Post-EEG:** Anlage aus 2006/07 fällt aus der 20-jährigen EEG-Förderung (Förderende 31.12.) → Umstieg auf Eigenverbrauch + Speicher wird wirtschaftlich zwingend. Gemessen 63.807 Anlagen in 2026, wachsend.
- **T3–T6 (Ausbau):** Speicher-Retrofit, Betreiberwechsel, Direktvermarktungs-Schwelle (≥100 kWp), Stilllegung.

## 2 · Die EINE Frage, die dieser Call beantworten muss
**Reicht dem Käufer das Signal allein (Firma + Standort + Kaufanlass + amtlicher Beleg-Link) — oder ist der Kontakt (Geschäftsführer-Name + Telefonnummer) der entscheidende Wert, ohne den das Produkt für ihn unvollständig ist?**

Das ist KEINE akademische Frage. An ihr hängt die gesamte Produktarchitektur:
- **Wenn Signal reicht:** Wir liefern reine Signale. Der Käufer recherchiert den Kontakt selbst und kontaktiert unter eigener Rechtsbasis. Für uns rechtlich sauber (keine Outreach-Haftung), schnell, schlank.
- **Wenn Kontakt entscheidend ist:** Wir müssen anreichern (Geschäftsführer + Telefon aus Impressum/Web). Das bringt uns DSGVO-/UWG-§7-Fragen und mehr Aufwand — ist aber evtl. genau das, wofür der Kunde zahlt.

**Aktueller Stand: Wir bauen technisch BEIDES** (das Vollpaket), aber die Anreicherung ist ein **zuschaltbares Modul**, das bewusst noch nicht scharf gestellt ist. Der Call entscheidet, ob und wann wir es scharf stellen. Darum ist dieser Call kein Nice-to-have, sondern die Weiche.

## 3 · Was wir wissen wollen (die Gesprächsziele, nach Wichtigkeit)
1. **Wert-Frage (s.o.):** Signal vs. Kontakt — was ist der eigentliche Wert? Wo würde der Käufer „das ist es" sagen?
2. **Liefer-Frage:** Wie will der Käufer das Signal bekommen? E-Mail-Liste, Dashboard-Login, CRM-Anbindung, Telefon? Wie oft — wöchentlich, täglich, sofort bei Eingang?
3. **Format-Frage:** Was muss in einem Signal stehen, damit er sofort handeln kann? Reicht Firma + kWp + Datum + Beleg-Link? Will er Branche, Anlagengröße, Einschätzung der Kaufwahrscheinlichkeit?
4. **Exklusivitäts-Frage:** Wie wichtig ist „nur ich bekomme dieses Signal in meinem Gebiet"? Was wäre ihm diese Exklusivität wert?
5. **Preis-Anker (das einzige echte Signal):** Kauft er heute schon Leads zu? Wo, und was zahlt er pro Lead? Was wäre ihm unser Feed wert — pro Signal oder pauschal pro Monat?
6. **Volumen-Frage:** Wie viele neue Gewerbespeicher-Aufträge macht er im Jahr? Wie viele qualifizierte Anlässe pro Woche könnte sein Vertrieb überhaupt verarbeiten?

## 4 · Wie man richtig fragt (Methodik — wichtig)
- **Nach Verhalten und Zahlen fragen, nie nach Meinung.** „Wären Sie interessiert?" ist wertlos. „Was zahlen Sie heute pro Lead?" ist Gold. Ein genannter Preis ist das einzige echte Nachfrage-Signal.
- **Nicht das Produkt verkaufen, sondern lernen.** Dieser Call ist Forschung. Je mehr der Käufer redet, desto besser. Offene Fragen, dann zuhören.
- **Die Wert-Frage nicht suggestiv stellen.** Nicht „brauchen Sie auch die Telefonnummer?" (lockt ein Ja), sondern „beschreiben Sie mir, was Sie tun, wenn ein qualifizierter Lead bei Ihnen reinkommt — Schritt für Schritt." Aus der Antwort hört man, ob der Kontakt der Engpass ist oder nicht.
- **Anti-Lowball beim Preis:** Erst seinen Ist-Preis erfragen (Anker), dann Exklusivität als Gegenwert positionieren.

## 5 · Käufer-Wissen (für die Gesprächsvorbereitung)
**Primärer Käufertyp:** regionale Speicher-Installateure / BESS-Anbieter, 10–50 Mitarbeiter, eigentümergeführt. Oft mit eigenem Vertrieb, der „keine Kaltakquise" will, sondern warme, qualifizierte Anlässe.

**Zweiter Käufertyp (Ausbau):** Direktvermarkter (für Anlagen ≥100 kWp) — andere Funktion, gleiche Datenbasis, nicht konkurrierend mit Installateuren → könnte dasselbe Gebiet exklusiv an beide gehen.

**Einwand-Bibliothek (was erfahrungsgemäß kommt):**
- „Leads generieren wir selbst." → Inbound ist meist Privat/Hausdach. Wir liefern exklusiv Gewerbe 30–750 kWp, frisch, ohne Speicher — ein Zusatzkanal, kein Ersatz.
- „MaStR-Adressen ziehe ich selbst." → Können Sie — aber wöchentlich filtern auf „ohne Speicher", anreichern, exklusiv pro Gebiet halten: Sie zahlen die gesparte Zeit, nicht die Zeile.
- „Wir machen keine Kaltakquise." → Kein kalter Lead: der Betrieb hat gerade selbst PV angemeldet → konkreter Anlass, näher an warm.
- „Was kostet das / ist das exklusiv?" → Genau das will ich von Ihnen lernen. Quelle ist das amtliche MaStR, wöchentlich frisch, exklusiv pro Region.
- „Woher die Daten — legal?" → Öffentliches MaStR der Bundesnetzagentur, Firmendaten gewerblicher Betreiber, Datenlizenz dl-de/by-2.0.

**Verifizierte Kandidaten:** Es existiert eine Liste von 31 recherchierten potenziellen Käufern (Speicher-Installateure + PV-Versicherer) mit Geschäftsführer-Namen und Telefonnummern aus den jeweiligen Impressen, samt Hook-Stärke 1–5. Liegt im Projekt (buyers.json). Die 10 mit der stärksten Passung wurden bereits per Mail kontaktiert — bisher 0 Antworten (Stand 15.06., wenige Tage alt).

## 6 · Was die Call-Session konkret produzieren soll
1. **Vorbereitung:** Gesprächsleitfaden mit den 6 Zielen aus §3, in eine natürliche Gesprächsdramaturgie gebracht (Einstieg → offene Fragen → Preis-Anker → Abschluss). Für Telefon UND für ein längeres Gespräch (z.B. über den Berater-Kontakt vermittelt).
2. **Während/nach dem Call:** Auswertungs-Raster, das die Antworten auf die 6 Ziele einfängt und die EINE Wert-Frage (Signal vs. Kontakt) klar beantwortet.
3. **Rückmeldung an den Build (Strang 1):** Eine klare Aussage — „Anreicherungs-Modul scharf stellen: ja/nein, und warum." Das ist der Output, der zur Build-Session zurückfließt.

## 7 · Wichtige Randbedingungen
- **Gründer ist Schweizer Bundesangestellter**, Nebenerwerb. Rechtliche Sauberkeit hat hohe Priorität. Das ist der Hauptgrund, warum „Signal statt Kontakt" attraktiv ist (verlagert Outreach-Haftung auf den Käufer). Der Call soll klären, ob dieser rechtliche Vorteil mit dem Kundenwunsch kollidiert.
- **Marktzugang kommt über einen Berater-Kontakt** (~2 Wochen): Energieberater + Technik-Netzwerk in Deutschland. Über diesen Weg könnten warme Gespräche mit echten Installateuren entstehen — die ideale Gelegenheit für genau diese Wert-Recherche.
- **Offene Rechtsfrage (separat, nicht Teil des Calls):** kommerzielle Weiterverbreitung der MaStR-Daten (dl-de/by-2.0) ist noch zu prüfen. Betrifft den Launch, nicht das Gespräch.

---
*Diese Datei ist self-contained. Die Call-Session braucht nur diese. Ergebnisse fließen über eine kurze Notiz zurück an die Build-/Konzept-Session (Strang 1).*
